import React from 'react';

const About = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Jarurat Care is an NGO focused on helping communities through technology.</p>
    </div>
  );
};

export default About;
